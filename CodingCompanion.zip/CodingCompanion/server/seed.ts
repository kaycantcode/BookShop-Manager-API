#!/usr/bin/env node
import { db } from "./db";
import { books, users, reviews } from "@shared/schema";

async function seedDatabase() {
  try {
    console.log("🌱 Seeding database with initial data...");

    // Clear existing data
    await db.delete(reviews);
    await db.delete(books);
    await db.delete(users);

    // Seed books
    const bookData = [
      { isbn: "978-0-7432-7356-5", title: "The Great Gatsby", author: "F. Scott Fitzgerald" },
      { isbn: "978-0-452-28423-4", title: "1984", author: "George Orwell" },
      { isbn: "978-0-06-112008-4", title: "To Kill a Mockingbird", author: "Harper Lee" },
      { isbn: "978-0-14-143951-8", title: "Pride and Prejudice", author: "Jane Austen" },
      { isbn: "978-0-7432-4722-4", title: "Catch-22", author: "Joseph Heller" },
    ];

    await db.insert(books).values(bookData);
    console.log("✅ Books seeded successfully");

    // Seed a test user
    const testUser = {
      username: "testuser",
      password: "password123",
    };

    await db.insert(users).values(testUser);
    console.log("✅ Test user created successfully");

    // Seed some reviews
    const reviewData = [
      {
        isbn: "978-0-7432-7356-5",
        username: "testuser",
        rating: 4.5,
        reviewText: "A timeless classic that beautifully captures the American Dream and its disillusionment.",
      },
      {
        isbn: "978-0-452-28423-4",
        username: "testuser",
        rating: 5.0,
        reviewText: "Orwell's masterpiece is more relevant today than ever. A chilling look at totalitarianism.",
      },
    ];

    await db.insert(reviews).values(reviewData);
    console.log("✅ Reviews seeded successfully");

    console.log("🎉 Database seeding completed!");
    process.exit(0);
  } catch (error) {
    console.error("❌ Error seeding database:", error);
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  seedDatabase();
}