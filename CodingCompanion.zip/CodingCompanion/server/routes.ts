import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertBookSchema, insertReviewSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Task 1: Get all books
  app.get("/api/books", async (req, res) => {
    try {
      const books = await storage.getAllBooks();
      const bookObj = books.reduce((acc, book) => {
        acc[book.isbn] = { title: book.title, author: book.author };
        return acc;
      }, {} as Record<string, { title: string; author: string }>);
      res.json(bookObj);
    } catch (error) {
      res.status(500).json({ message: "Failed to get books" });
    }
  });

  // Task 2: Get book by ISBN
  app.get("/api/books/isbn/:isbn", async (req, res) => {
    try {
      const book = await storage.getBookByISBN(req.params.isbn);
      if (!book) {
        return res.status(404).json({ message: "Book not found" });
      }
      res.json({ title: book.title, author: book.author });
    } catch (error) {
      res.status(500).json({ message: "Failed to get book" });
    }
  });

  // Task 3: Get books by author
  app.get("/api/books/author/:author", async (req, res) => {
    try {
      const books = await storage.getBooksByAuthor(req.params.author);
      const bookObj = books.reduce((acc, book) => {
        acc[book.isbn] = { title: book.title, author: book.author };
        return acc;
      }, {} as Record<string, { title: string; author: string }>);
      res.json(bookObj);
    } catch (error) {
      res.status(500).json({ message: "Failed to get books by author" });
    }
  });

  // Task 4: Get books by title
  app.get("/api/books/title/:title", async (req, res) => {
    try {
      const books = await storage.getBooksByTitle(req.params.title);
      const bookObj = books.reduce((acc, book) => {
        acc[book.isbn] = { title: book.title, author: book.author };
        return acc;
      }, {} as Record<string, { title: string; author: string }>);
      res.json(bookObj);
    } catch (error) {
      res.status(500).json({ message: "Failed to get books by title" });
    }
  });

  // Task 5: Get book reviews
  app.get("/api/books/review/:isbn", async (req, res) => {
    try {
      const reviews = await storage.getReviewsByISBN(req.params.isbn);
      const reviewObj = reviews.reduce((acc, review) => {
        acc[review.username] = {
          rating: review.rating,
          review: review.reviewText
        };
        return acc;
      }, {} as Record<string, { rating: number; review: string }>);
      res.json(reviewObj);
    } catch (error) {
      res.status(500).json({ message: "Failed to get reviews" });
    }
  });

  // Task 6: Register user
  app.post("/api/users/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ message: "User already exists" });
      }

      const user = await storage.createUser(userData);
      res.json({ message: "User registered successfully", username: user.username });
    } catch (error) {
      res.status(400).json({ message: "Registration failed", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  // Task 7: Login user
  app.post("/api/users/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      const user = await storage.getUserByUsername(username);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      res.json({ message: "Login successful", username: user.username });
    } catch (error) {
      res.status(500).json({ message: "Login failed" });
    }
  });

  // Task 8: Add/Update review
  app.post("/api/books/review/:isbn", async (req, res) => {
    try {
      const reviewData = insertReviewSchema.parse({
        ...req.body,
        isbn: req.params.isbn
      });

      const review = await storage.createOrUpdateReview(reviewData);
      res.json({ message: "Review added/updated successfully" });
    } catch (error) {
      res.status(400).json({ message: "Failed to add/update review", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  // Task 9: Delete review
  app.delete("/api/books/review/:isbn", async (req, res) => {
    try {
      const { username } = req.body;
      const deleted = await storage.deleteReview(req.params.isbn, username);
      
      if (!deleted) {
        return res.status(404).json({ message: "Review not found" });
      }

      res.json({ message: "Review deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete review" });
    }
  });

  // Additional endpoints for frontend
  app.get("/api/users", async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users.map(user => ({ id: user.id, username: user.username, createdAt: user.createdAt })));
    } catch (error) {
      res.status(500).json({ message: "Failed to get users" });
    }
  });

  app.get("/api/reviews", async (req, res) => {
    try {
      const reviews = await storage.getAllReviews();
      res.json(reviews);
    } catch (error) {
      res.status(500).json({ message: "Failed to get reviews" });
    }
  });

  app.get("/api/stats", async (req, res) => {
    try {
      const books = await storage.getAllBooks();
      const users = await storage.getAllUsers();
      const reviews = await storage.getAllReviews();
      
      res.json({
        totalBooks: books.length,
        totalUsers: users.length,
        totalReviews: reviews.length,
        apiEndpoints: 13
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to get stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
