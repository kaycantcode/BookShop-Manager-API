import { users, books, reviews, type User, type InsertUser, type Book, type InsertBook, type Review, type InsertReview } from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>;

  // Book operations
  getAllBooks(): Promise<Book[]>;
  getBookByISBN(isbn: string): Promise<Book | undefined>;
  getBooksByAuthor(author: string): Promise<Book[]>;
  getBooksByTitle(title: string): Promise<Book[]>;
  createBook(book: InsertBook): Promise<Book>;

  // Review operations
  getReviewsByISBN(isbn: string): Promise<Review[]>;
  getReviewByISBNAndUsername(isbn: string, username: string): Promise<Review | undefined>;
  createOrUpdateReview(review: InsertReview): Promise<Review>;
  deleteReview(isbn: string, username: string): Promise<boolean>;
  getAllReviews(): Promise<Review[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private books: Map<string, Book>;
  private reviews: Map<string, Review>;
  private currentUserId: number;
  private currentReviewId: number;

  constructor() {
    this.users = new Map();
    this.books = new Map();
    this.reviews = new Map();
    this.currentUserId = 1;
    this.currentReviewId = 1;
    
    // Initialize with sample data
    this.initializeData();
  }

  private async initializeData() {
    // Sample books
    const sampleBooks: InsertBook[] = [
      { isbn: "978-0-7432-7356-5", title: "The Great Gatsby", author: "F. Scott Fitzgerald" },
      { isbn: "978-0-452-28423-4", title: "1984", author: "George Orwell" },
      { isbn: "978-0-06-112008-4", title: "To Kill a Mockingbird", author: "Harper Lee" },
      { isbn: "978-0-14-143951-8", title: "Pride and Prejudice", author: "Jane Austen" },
    ];

    for (const book of sampleBooks) {
      this.books.set(book.isbn, book);
    }
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id, 
      createdAt: new Date() 
    };
    this.users.set(id, user);
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async getAllBooks(): Promise<Book[]> {
    return Array.from(this.books.values());
  }

  async getBookByISBN(isbn: string): Promise<Book | undefined> {
    return this.books.get(isbn);
  }

  async getBooksByAuthor(author: string): Promise<Book[]> {
    return Array.from(this.books.values()).filter(
      book => book.author.toLowerCase() === author.toLowerCase()
    );
  }

  async getBooksByTitle(title: string): Promise<Book[]> {
    return Array.from(this.books.values()).filter(
      book => book.title.toLowerCase() === title.toLowerCase()
    );
  }

  async createBook(book: InsertBook): Promise<Book> {
    this.books.set(book.isbn, book);
    return book;
  }

  async getReviewsByISBN(isbn: string): Promise<Review[]> {
    return Array.from(this.reviews.values()).filter(
      review => review.isbn === isbn
    );
  }

  async getReviewByISBNAndUsername(isbn: string, username: string): Promise<Review | undefined> {
    return Array.from(this.reviews.values()).find(
      review => review.isbn === isbn && review.username === username
    );
  }

  async createOrUpdateReview(reviewData: InsertReview): Promise<Review> {
    const existing = await this.getReviewByISBNAndUsername(reviewData.isbn, reviewData.username);
    
    if (existing) {
      const updated: Review = {
        ...existing,
        rating: reviewData.rating,
        reviewText: reviewData.reviewText,
      };
      this.reviews.set(`${existing.isbn}-${existing.username}`, updated);
      return updated;
    } else {
      const id = this.currentReviewId++;
      const review: Review = {
        ...reviewData,
        id,
        createdAt: new Date(),
      };
      this.reviews.set(`${review.isbn}-${review.username}`, review);
      return review;
    }
  }

  async deleteReview(isbn: string, username: string): Promise<boolean> {
    return this.reviews.delete(`${isbn}-${username}`);
  }

  async getAllReviews(): Promise<Review[]> {
    return Array.from(this.reviews.values());
  }
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async getAllBooks(): Promise<Book[]> {
    return await db.select().from(books);
  }

  async getBookByISBN(isbn: string): Promise<Book | undefined> {
    const [book] = await db.select().from(books).where(eq(books.isbn, isbn));
    return book || undefined;
  }

  async getBooksByAuthor(author: string): Promise<Book[]> {
    return await db.select().from(books).where(eq(books.author, author));
  }

  async getBooksByTitle(title: string): Promise<Book[]> {
    return await db.select().from(books).where(eq(books.title, title));
  }

  async createBook(book: InsertBook): Promise<Book> {
    const [newBook] = await db
      .insert(books)
      .values(book)
      .returning();
    return newBook;
  }

  async getReviewsByISBN(isbn: string): Promise<Review[]> {
    return await db.select().from(reviews).where(eq(reviews.isbn, isbn));
  }

  async getReviewByISBNAndUsername(isbn: string, username: string): Promise<Review | undefined> {
    const [review] = await db
      .select()
      .from(reviews)
      .where(and(eq(reviews.isbn, isbn), eq(reviews.username, username)));
    return review || undefined;
  }

  async createOrUpdateReview(reviewData: InsertReview): Promise<Review> {
    const existing = await this.getReviewByISBNAndUsername(reviewData.isbn, reviewData.username);
    
    if (existing) {
      const [updated] = await db
        .update(reviews)
        .set({
          rating: reviewData.rating,
          reviewText: reviewData.reviewText,
        })
        .where(and(eq(reviews.isbn, reviewData.isbn), eq(reviews.username, reviewData.username)))
        .returning();
      return updated;
    } else {
      const [review] = await db
        .insert(reviews)
        .values(reviewData)
        .returning();
      return review;
    }
  }

  async deleteReview(isbn: string, username: string): Promise<boolean> {
    const result = await db
      .delete(reviews)
      .where(and(eq(reviews.isbn, isbn), eq(reviews.username, username)))
      .returning();
    return result.length > 0;
  }

  async getAllReviews(): Promise<Review[]> {
    return await db.select().from(reviews);
  }
}

// Use database storage instead of memory storage
export const storage = new DatabaseStorage();
