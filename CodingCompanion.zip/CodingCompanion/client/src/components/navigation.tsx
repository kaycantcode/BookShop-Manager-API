import { LibraryBig, Github } from "lucide-react";
import { Button } from "@/components/ui/button";

type Section = "dashboard" | "books" | "users" | "reviews" | "api-test";

interface NavigationProps {
  activeSection: Section;
  onSectionChange: (section: Section) => void;
}

export default function Navigation({ activeSection, onSectionChange }: NavigationProps) {
  const navItems = [
    { id: "dashboard" as Section, label: "Dashboard" },
    { id: "books" as Section, label: "Books" },
    { id: "users" as Section, label: "Users" },
    { id: "reviews" as Section, label: "Reviews" },
    { id: "api-test" as Section, label: "API Test" },
  ];

  return (
    <header className="bg-white shadow-lg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <LibraryBig className="text-primary w-8 h-8 mr-3" />
              <h1 className="text-xl font-medium text-gray-900">BookShop API Manager</h1>
            </div>
            <nav className="hidden md:ml-8 md:flex md:space-x-8">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => onSectionChange(item.id)}
                  className={`px-1 pt-1 pb-4 text-sm font-medium transition-colors ${
                    activeSection === item.id
                      ? "text-primary border-b-2 border-primary"
                      : "text-gray-500 hover:text-gray-700"
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </nav>
          </div>
          <div className="flex items-center space-x-4">
            <span className="hidden md:block text-sm text-gray-700">Server Status:</span>
            <div className="flex items-center">
              <div className="w-2 h-2 bg-green-600 rounded-full mr-2"></div>
              <span className="text-sm text-gray-600">localhost:5000</span>
            </div>
            <Button variant="outline" size="sm" className="flex items-center">
              <Github className="w-4 h-4 mr-1" />
              GitHub
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
