import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Star, Edit, Trash2, MessageSquare, Save, X } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const reviewSchema = z.object({
  isbn: z.string().min(1, "ISBN is required"),
  username: z.string().min(1, "Username is required"),
  rating: z.number().min(1).max(5),
  reviewText: z.string().min(10, "Review must be at least 10 characters"),
});

export default function ReviewManagement() {
  const [selectedBook, setSelectedBook] = useState("");
  const [currentUser, setCurrentUser] = useState("testuser"); // Simulated logged-in user
  const [editingReview, setEditingReview] = useState<{ isbn: string; username: string } | null>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: booksData } = useQuery({
    queryKey: ["/api/books"],
  });

  const { data: reviews, isLoading } = useQuery({
    queryKey: ["/api/reviews"],
  });

  const form = useForm({
    resolver: zodResolver(reviewSchema),
    defaultValues: {
      isbn: "",
      username: "",
      rating: 5,
      reviewText: "",
    },
  });

  const editForm = useForm({
    resolver: zodResolver(reviewSchema),
    defaultValues: {
      isbn: "",
      username: "",
      rating: 5,
      reviewText: "",
    },
  });

  const addReviewMutation = useMutation({
    mutationFn: async (data: z.infer<typeof reviewSchema>) => {
      const response = await apiRequest("POST", `/api/books/review/${data.isbn}`, {
        username: data.username,
        rating: data.rating,
        reviewText: data.reviewText,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Success", description: "Review added successfully" });
      form.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/reviews"] });
    },
    onError: (error: any) => {
      toast({ 
        title: "Error", 
        description: error.message || "Failed to add review",
        variant: "destructive" 
      });
    },
  });

  const updateReviewMutation = useMutation({
    mutationFn: async (data: z.infer<typeof reviewSchema>) => {
      const response = await apiRequest("POST", `/api/books/review/${data.isbn}`, {
        username: data.username,
        rating: data.rating,
        reviewText: data.reviewText,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Success", description: "Review updated successfully" });
      setEditingReview(null);
      editForm.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/reviews"] });
    },
    onError: (error: any) => {
      toast({ 
        title: "Error", 
        description: error.message || "Failed to update review",
        variant: "destructive" 
      });
    },
  });

  const deleteReviewMutation = useMutation({
    mutationFn: async ({ isbn, username }: { isbn: string; username: string }) => {
      const response = await apiRequest("DELETE", `/api/books/review/${isbn}`, { username });
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Success", description: "Review deleted successfully" });
      queryClient.invalidateQueries({ queryKey: ["/api/reviews"] });
    },
    onError: (error: any) => {
      toast({ 
        title: "Error", 
        description: error.message || "Failed to delete review",
        variant: "destructive" 
      });
    },
  });

  const onSubmit = (data: z.infer<typeof reviewSchema>) => {
    addReviewMutation.mutate(data);
  };

  const onEditSubmit = (data: z.infer<typeof reviewSchema>) => {
    updateReviewMutation.mutate(data);
  };

  const handleDeleteReview = (isbn: string, username: string) => {
    deleteReviewMutation.mutate({ isbn, username });
  };

  const handleEditReview = (review: any) => {
    setEditingReview({ isbn: review.isbn, username: review.username });
    editForm.reset({
      isbn: review.isbn,
      username: review.username,
      rating: review.rating,
      reviewText: review.reviewText,
    });
  };

  const handleCancelEdit = () => {
    setEditingReview(null);
    editForm.reset();
  };

  const canEditReview = (reviewUsername: string) => {
    return currentUser === reviewUsername;
  };

  // Convert books object to array for selection
  const books = booksData ? Object.entries(booksData).map(([isbn, book]) => ({
    isbn,
    title: book.title,
    author: book.author
  })) : [];

  // Filter reviews by selected book
  const filteredReviews = selectedBook && selectedBook !== "all"
    ? reviews?.filter((review: any) => review.isbn === selectedBook) 
    : reviews || [];

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`w-4 h-4 ${i < rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}`}
      />
    ));
  };

  return (
    <section className="mb-8">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-medium text-gray-900">Review Management</h2>
        <Button className="flex items-center">
          <MessageSquare className="w-4 h-4 mr-2" />
          Add Review
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Add Review Form */}
        <div className="lg:col-span-1 space-y-6">
          <Card>
            <CardContent className="p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Add Review</h3>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="isbn"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Book ISBN</FormLabel>
                        <FormControl>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select a book" />
                            </SelectTrigger>
                            <SelectContent>
                              {books.map((book) => (
                                <SelectItem key={book.isbn} value={book.isbn}>
                                  {book.title} ({book.isbn})
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Username</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter username" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="rating"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Rating</FormLabel>
                        <FormControl>
                          <Select onValueChange={(value) => field.onChange(Number(value))} value={field.value.toString()}>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="1">⭐ 1 Star</SelectItem>
                              <SelectItem value="2">⭐⭐ 2 Stars</SelectItem>
                              <SelectItem value="3">⭐⭐⭐ 3 Stars</SelectItem>
                              <SelectItem value="4">⭐⭐⭐⭐ 4 Stars</SelectItem>
                              <SelectItem value="5">⭐⭐⭐⭐⭐ 5 Stars</SelectItem>
                            </SelectContent>
                          </Select>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="reviewText"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Review Text</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Write your review..." 
                            rows={4}
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="flex space-x-3">
                    <Button 
                      type="submit" 
                      className="flex-1" 
                      disabled={addReviewMutation.isPending}
                    >
                      {addReviewMutation.isPending ? "Adding..." : "Add Review"}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>

          {/* Current User Info */}
          <Card>
            <CardContent className="p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Current User</h3>
              <div className="flex items-center space-x-3">
                <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center">
                  <span className="text-white text-sm font-medium">
                    {currentUser.charAt(0).toUpperCase()}
                  </span>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-900">{currentUser}</p>
                  <p className="text-xs text-gray-500">You can only edit your own reviews</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Reviews List */}
        <div className="lg:col-span-2">
          <Card className="overflow-hidden">
            <CardContent className="p-6 border-b border-gray-200">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-medium text-gray-900">Recent Reviews</h3>
                <Select value={selectedBook} onValueChange={setSelectedBook}>
                  <SelectTrigger className="w-64">
                    <SelectValue placeholder="All Books" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Books</SelectItem>
                    {books.map((book) => (
                      <SelectItem key={book.isbn} value={book.isbn}>
                        {book.title}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>

            <div className="divide-y divide-gray-200 max-h-96 overflow-y-auto">
              {isLoading ? (
                <div className="p-6 text-center text-gray-500">Loading reviews...</div>
              ) : filteredReviews.length === 0 ? (
                <div className="p-6 text-center text-gray-500">No reviews found</div>
              ) : (
                filteredReviews.map((review: any) => {
                  const book = books.find(b => b.isbn === review.isbn);
                  const isEditing = editingReview?.isbn === review.isbn && editingReview?.username === review.username;
                  const canEdit = canEditReview(review.username);
                  
                  return (
                    <div key={`${review.isbn}-${review.username}`} className="p-6 hover:bg-gray-50">
                      {isEditing ? (
                        <Form {...editForm}>
                          <form onSubmit={editForm.handleSubmit(onEditSubmit)} className="space-y-4">
                            <div className="flex items-center justify-between mb-4">
                              <h4 className="text-lg font-medium">Edit Review</h4>
                              <div className="flex space-x-2">
                                <Button
                                  type="submit"
                                  size="sm"
                                  disabled={updateReviewMutation.isPending}
                                >
                                  <Save className="w-4 h-4 mr-1" />
                                  {updateReviewMutation.isPending ? "Saving..." : "Save"}
                                </Button>
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="sm"
                                  onClick={handleCancelEdit}
                                >
                                  <X className="w-4 h-4 mr-1" />
                                  Cancel
                                </Button>
                              </div>
                            </div>
                            
                            <div className="grid grid-cols-2 gap-4">
                              <FormField
                                control={editForm.control}
                                name="rating"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Rating</FormLabel>
                                    <FormControl>
                                      <Select onValueChange={(value) => field.onChange(Number(value))} value={field.value.toString()}>
                                        <SelectTrigger>
                                          <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                          <SelectItem value="1">⭐ 1 Star</SelectItem>
                                          <SelectItem value="2">⭐⭐ 2 Stars</SelectItem>
                                          <SelectItem value="3">⭐⭐⭐ 3 Stars</SelectItem>
                                          <SelectItem value="4">⭐⭐⭐⭐ 4 Stars</SelectItem>
                                          <SelectItem value="5">⭐⭐⭐⭐⭐ 5 Stars</SelectItem>
                                        </SelectContent>
                                      </Select>
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              
                              <div className="text-sm text-gray-500">
                                <p><strong>Book:</strong> {book?.title}</p>
                                <p><strong>User:</strong> {review.username}</p>
                              </div>
                            </div>
                            
                            <FormField
                              control={editForm.control}
                              name="reviewText"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Review Text</FormLabel>
                                  <FormControl>
                                    <Textarea 
                                      placeholder="Write your review..." 
                                      rows={4}
                                      {...field} 
                                    />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </form>
                        </Form>
                      ) : (
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center mb-2">
                              <div className="flex items-center">
                                <span className="text-sm font-medium text-gray-900 mr-2">{review.username}</span>
                                <div className="flex items-center">
                                  {renderStars(review.rating)}
                                </div>
                                <span className="text-sm text-gray-500 ml-2">{review.rating.toFixed(1)}</span>
                              </div>
                              <span className="text-xs text-gray-400 ml-auto">
                                {review.createdAt ? new Date(review.createdAt).toLocaleDateString() : 'Recent'}
                              </span>
                            </div>
                            <div className="mb-2">
                              <span className="text-sm font-medium text-gray-600">Book:</span>
                              <span className="text-sm text-gray-900 ml-1">{book?.title}</span>
                              <span className="text-xs text-gray-500 ml-2">({review.isbn})</span>
                            </div>
                            <p className="text-sm text-gray-700">{review.reviewText}</p>
                          </div>
                          <div className="ml-4 flex space-x-2">
                            <Button 
                              variant="ghost" 
                              size="sm"
                              onClick={() => handleEditReview(review)}
                              disabled={!canEdit}
                              title={canEdit ? "Edit this review" : "You can only edit your own reviews"}
                            >
                              <Edit className={`w-4 h-4 ${canEdit ? 'text-blue-600' : 'text-gray-400'}`} />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm"
                              onClick={() => handleDeleteReview(review.isbn, review.username)}
                              disabled={deleteReviewMutation.isPending || !canEdit}
                              title={canEdit ? "Delete this review" : "You can only delete your own reviews"}
                            >
                              <Trash2 className={`w-4 h-4 ${canEdit ? 'text-red-600' : 'text-gray-400'}`} />
                            </Button>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          </Card>
        </div>
      </div>
    </section>
  );
}
