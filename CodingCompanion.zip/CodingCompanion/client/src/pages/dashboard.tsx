import { useState } from "react";
import Navigation from "@/components/navigation";
import BookManagement from "@/components/book-management";
import UserManagement from "@/components/user-management";
import ReviewManagement from "@/components/review-management";
import APITest from "@/components/api-test";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { LibraryBig, Users, Star, Code } from "lucide-react";

type Section = "dashboard" | "books" | "users" | "reviews" | "api-test";

export default function Dashboard() {
  const [activeSection, setActiveSection] = useState<Section>("dashboard");

  const { data: stats } = useQuery({
    queryKey: ["/api/stats"],
  });

  const renderSection = () => {
    switch (activeSection) {
      case "books":
        return <BookManagement />;
      case "users":
        return <UserManagement />;
      case "reviews":
        return <ReviewManagement />;
      case "api-test":
        return <APITest />;
      default:
        return (
          <section className="mb-8">
            <div className="mb-6">
              <h2 className="text-2xl font-medium text-gray-900 mb-2">Dashboard Overview</h2>
              <p className="text-gray-600">Coursera Book Management API - All 13 tasks implemented</p>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <LibraryBig className="text-primary text-3xl w-8 h-8" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Total Books</p>
                      <p className="text-2xl font-semibold text-gray-900">{stats?.totalBooks || 0}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <Users className="text-green-600 w-8 h-8" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Registered Users</p>
                      <p className="text-2xl font-semibold text-gray-900">{stats?.totalUsers || 0}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <Star className="text-orange-500 w-8 h-8" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Total Reviews</p>
                      <p className="text-2xl font-semibold text-gray-900">{stats?.totalReviews || 0}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <Code className="text-primary w-8 h-8" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">API Endpoints</p>
                      <p className="text-2xl font-semibold text-gray-900">13</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Task Completion Status */}
            <Card className="mb-8">
              <CardContent className="p-6">
                <h3 className="text-lg font-medium text-gray-900 mb-4">Coursera Project Tasks Status</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {[
                    { task: "Task 1: Get all books", endpoint: "GET /books" },
                    { task: "Task 2: Get by ISBN", endpoint: "GET /books/isbn/:isbn" },
                    { task: "Task 3: Get by author", endpoint: "GET /books/author/:author" },
                    { task: "Task 4: Get by title", endpoint: "GET /books/title/:title" },
                    { task: "Task 5: Get book reviews", endpoint: "GET /books/review/:isbn" },
                    { task: "Task 6: User registration", endpoint: "POST /users/register" },
                    { task: "Task 7: User login", endpoint: "POST /users/login" },
                    { task: "Task 8: Add/Update review", endpoint: "POST /books/review/:isbn" },
                    { task: "Task 9: Delete review", endpoint: "DELETE /books/review/:isbn" },
                    { task: "Task 10: Async callback", endpoint: "Node.js client" },
                    { task: "Task 11: Promises", endpoint: "Node.js client" },
                    { task: "Task 12: Author search", endpoint: "Node.js client" },
                    { task: "Task 13: Title search", endpoint: "Node.js client" },
                  ].map((item, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center">
                        <div className="w-2 h-2 bg-green-600 rounded-full mr-2"></div>
                        <span className="text-sm text-gray-700">{item.task}</span>
                      </div>
                      <span className="text-xs text-gray-500">{item.endpoint}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </section>
        );
    }
  };

  return (
    <div className="bg-gray-50 min-h-screen font-sans">
      <Navigation activeSection={activeSection} onSectionChange={setActiveSection} />
      
      <main className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        {renderSection()}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-12">
        <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-4">
              <LibraryBig className="text-primary w-6 h-6" />
              <div>
                <div className="text-sm font-medium text-gray-900">BookShop API Manager</div>
                <div className="text-xs text-gray-500">Coursera Final Project - All 13 Tasks Complete</div>
              </div>
            </div>
            <div className="flex items-center space-x-6 text-sm text-gray-600">
              <span>Express.js</span>
              <span>Node.js</span>
              <span>REST API</span>
              <span>Axios</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
